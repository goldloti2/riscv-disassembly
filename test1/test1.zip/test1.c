#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("hello world.\n");
    return 0;
}